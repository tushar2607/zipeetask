# api/tests.py
from django.urls import reverse
from rest_framework.test import APITestCase
from rest_framework import status
from django.contrib.auth.models import User
from .models import Task

class TaskAPITestCase(APITestCase):
    def setUp(self):
        self.user = User.objects.create_user(username="testuser", password="password123")
        self.login_url = reverse("token_obtain_pair")
        response = self.client.post(self.login_url, {"username": "testuser", "password": "password123"})
        self.token = response.data["access"]
        self.auth_header = {"HTTP_AUTHORIZATION": f"Bearer {self.token}"}
        self.task_url = reverse("task-list")

    def test_create_task(self):
        data = {"title": "Test Task", "description": "This is a test task", "completed": False}
        response = self.client.post(self.task_url, data, **self.auth_header)
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)

    def test_list_tasks(self):
        Task.objects.create(title="Sample Task", user=self.user)
        response = self.client.get(self.task_url, **self.auth_header)
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertGreaterEqual(len(response.data["results"]), 1)

    def test_get_single_task(self):
        task = Task.objects.create(title="Single", user=self.user)
        url = reverse("task-detail", args=[task.id])
        response = self.client.get(url, **self.auth_header)
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data["title"], "Single")

    def test_update_task(self):
        task = Task.objects.create(title="To Update", user=self.user)
        url = reverse("task-detail", args=[task.id])
        response = self.client.put(url, {"title": "Updated Task", "completed": True}, **self.auth_header)
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data["title"], "Updated Task")

    def test_delete_task(self):
        task = Task.objects.create(title="To Delete", user=self.user)
        url = reverse("task-detail", args=[task.id])
        response = self.client.delete(url, **self.auth_header)
        self.assertEqual(response.status_code, status.HTTP_204_NO_CONTENT)

    def test_unauthorized_access(self):
        response = self.client.get(self.task_url)
        self.assertEqual(response.status_code, status.HTTP_401_UNAUTHORIZED)
